
MSegments <- function(seg.cna.obj, cgh){

	# Ajoute les valeurs m�dianes de segmentation pour chaque segment

	data <- cgh$cgh
	
	seg.start <- seg.cna.obj$output$loc.start
	seg.end <- seg.cna.obj$output$loc.end			
	seg.len <- seg.cna.obj$output$num.mark
	cum.seg.len <- cumsum(seg.len)
	s <- data$ChrStart[cum.seg.len]
	e <- data$ChrEnd[cum.seg.len]
	if(!is.null(e)) seg.end <- seg.end + (e-s)


	seg.med <- c()
	for(i in 1:length(seg.start)){
		index <- which(data$GenomicPos>= seg.start[i] & data$GenomicPos<=seg.end[i])
		tmp <- tukey.biweight(data$Log2Ratio[index])
		seg.med <- c(seg.med, tmp)
		}
	seg.cna.obj$output <- cbind.data.frame(seg.cna.obj$output, seg.med = seg.med)
	return(seg.cna.obj)
}